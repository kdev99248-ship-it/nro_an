package event;

/*
 * @Author: NgojcDev
 */

import interfaces.Event;

public class TopUp extends Event {

    @Override
    public void npc() {
    }

}
