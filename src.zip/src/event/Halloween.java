package event;

/*
 * @Author: NgojcDev
 */

import consts.BossID;
import interfaces.Event;

public class Halloween extends Event {
    @Override
    public void boss() {

    }
}
