/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;
/**
 *
 * @author Administrator
 */
public class LearnSkill {
    public long Time;
    public short ItemTemplateSkillId;
    public int Potential;
    public LearnSkill()
    {
        Time = -1;
        ItemTemplateSkillId = -1;
        Potential = 0;
    }
}
