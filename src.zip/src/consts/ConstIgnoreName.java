package consts;

/*
 * @Author: NgojcDev
 */

public class ConstIgnoreName {

    public static final String[] IGNORE_NAME = {};

}
