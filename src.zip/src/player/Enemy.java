package player;

/*
 * @Author: NgojcDev
 */

public class Enemy extends Friend {

}
