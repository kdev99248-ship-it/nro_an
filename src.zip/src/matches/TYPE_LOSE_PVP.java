package matches;

/*
 * @Author: NgojcDev
 */

public enum TYPE_LOSE_PVP {

    RUNS_AWAY,
    DEAD

}
