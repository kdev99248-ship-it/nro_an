package matches;

/*
 * @Author: NgojcDev
 */

public enum TYPE_PVP {

    THACH_DAU,
    LUYEN_TAP,
    TRA_THU,
    CUU_SAT,
    DAI_HOI_VO_THUAT

}
