package interfaces;

public interface IServerClose {

    void serverClose();
}
